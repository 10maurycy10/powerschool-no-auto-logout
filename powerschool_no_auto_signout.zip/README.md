# Powerschool anti autosignout

An extention wich will prevent powerschool from signing you out after a few seconds.

## Installation Chrome (and diriveratives Edge/Brave...)

Download the .crx file.

Go to the extention page, Drop Down -> Settings -> Extentions.

Enable the "Developer Mode" Toggle.

Drag the .crx file into the page to install it.
